
import ollama

# Write a prompt
prompt = """
Explain Artificial Intelligence in simple words.
Give five real-world examples suitable for a
first-year engineering student.
"""

# Send prompt to local AI model
response = ollama.chat(
    model="llama3.2:1b",
    messages=[
        {"role": "user", "content": prompt}
    ]
)

# Display the response
print("\n========== LLM RESPONSE ==========\n")
print(response["message"]["content"])
print("\n==================================")
